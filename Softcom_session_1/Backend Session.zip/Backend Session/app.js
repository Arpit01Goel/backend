const express = require("express");
const app = express();
const port = 8080;

const methodOverride = require("method-override");
const path = require("path");
// const mongoose = require('mongoose');    

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views")); // Set views directory
app.use(methodOverride("_method")); // Method override

app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));


// connection with mongodb 
// main()
//     .then(() => {console.log("connection made successfully");})
//     .catch((err) => {console.log(err)});

// async function main()
// {
//     await mongoose.connect("mongodb://127.0.0.1:27017/test");  // we're using test database in this case.
// }

// const studentDetails = new mongoose.Schema({
//     name:String,
//     entryNumber:String,
//     url: String,
//     dept: String,
// });

// const User = mongoose.model("User", studentDetails); 

